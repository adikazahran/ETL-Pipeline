import pytest
from unittest.mock import patch, MagicMock
import pandas as pd
from utils.load import save_to_csv, display_sample, load_to_gsheet, load_to_postgres

SAMPLE_DATA = [
    {'Title': 'Product 1', 'Price': 100.0, 'Rating': 4.5},
    {'Title': 'Product 2', 'Price': 200.0, 'Rating': 3.5}
]

def test_save_to_csv_success(tmp_path):
    file_path = tmp_path / "test.csv"
    result = save_to_csv(SAMPLE_DATA, file_path)
    assert result is True
    assert file_path.exists()

    df = pd.read_csv(file_path)
    assert len(df) == 2
    assert "Title" in df.columns

@patch('pandas.DataFrame.to_csv')
def test_save_to_csv_failure(mock_to_csv):
    mock_to_csv.side_effect = Exception("Write error")
    result = save_to_csv(SAMPLE_DATA, "test.csv")
    assert result is False

def test_display_sample(capsys):
    display_sample(SAMPLE_DATA)
    captured = capsys.readouterr()
    assert "Product 1" in captured.out
    assert "Product 2" in captured.out
    assert "Sample of" in captured.out

def test_display_sample_empty(capsys):
    display_sample([])
    captured = capsys.readouterr()
    assert "No data to display" in captured.out

@patch('utils.load.Credentials.from_service_account_file')
@patch('utils.load.build')
def test_load_to_gsheet(mock_build, mock_creds):
    mock_service = MagicMock()
    mock_build.return_value = mock_service
    mock_service.spreadsheets.return_value.values.return_value.update.return_value.execute.return_value = {
        'updatedCells': 6
    }
    
    result = load_to_gsheet(SAMPLE_DATA)
    assert result is True

@patch('sqlalchemy.create_engine')
@patch('pandas.DataFrame.to_sql')
def test_load_to_postgres(mock_to_sql, mock_engine):
    mock_engine.return_value = MagicMock()
    result = load_to_postgres(SAMPLE_DATA, "postgresql://user:pass@localhost/db")
    assert result is True
